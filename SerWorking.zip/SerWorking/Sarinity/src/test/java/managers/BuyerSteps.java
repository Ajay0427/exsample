package managers;
import net.thucydides.core.annotations.Step;

public class BuyerSteps {

    HomePage homePage;                                          
    SearchResultsPage searchResultsPage;

    @Step                                                       
    public void opens_etsy_home_page() {
       System.out.println("BDD1");
    }

    @Step
    public void searches_for_items_containing(String keywords) {
    	  System.out.println(keywords);
    }

    @Step
    public void should_see_items_related_to(String keywords) {
    	System.out.println(keywords);
    	//List<String> resultTitles = searchResultsPage.getResultTitles();
       /* resultTitles.stream().forEach(title -> assertThat(title.contains(keywords)));*/
    }
}