/**
 * 
 */
package stepDefination;

import org.junit.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

/**
 * @author ajay
 *
 */
public class stepDefination {

	@Given("^User is on login Page$")
	public void User_is_on_login_Page()  {
	    
		System.out.println(" Login Page");
	    ;
	}

	@When("^user enters \"([^\"]*)\"$")
	public void user_enters(String arg1)  {
		System.out.println(" Login Page" + arg1);
		
	}

	@When("^user enters password \"([^\"]*)\"$")
	public void user_enters_password(String arg1)  {

		Assert.assertTrue(arg1.equalsIgnoreCase("password2"));
	}
	@When("^user clicks on sign in button$")
	public void user_clicks_on_sign_in_button()  {
	    
		System.out.println(" Login Page" );
	}

	@Then("^User logged in successfully$")
	public void User_logged_in_successfully()  {
		
		System.out.println(" Login successfully");
	    
	    ;
	}

	@When("^navigate to landing page$")
	public void navigate_to_landing_page()  {
	   
	   
	}

	@When("^click on home button$")
	public void click_on_home_button()  {
	   
	   
	}

	@Then("^User navigated to payment page$")
	public void user_navigated_to_payment_page()  {
	   
	   
	}

	@Then("^User navigated to logout page$")
	public void user_navigated_to_logout_page()  {
	   
	   
	}
	
	
}
