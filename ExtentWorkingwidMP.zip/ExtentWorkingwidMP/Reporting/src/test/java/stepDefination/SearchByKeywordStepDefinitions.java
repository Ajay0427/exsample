package stepDefination;

import managers.BuyerSteps;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SearchByKeywordStepDefinitions {
	 BuyerSteps buyer = new BuyerSteps();
    @Given("I want to buy (.*)")
    public void buyerWantsToBuy(String article) {
        buyer.opens_etsy_home_page();
    }

    @When("I search for items containing '(.*)'")
    public void searchByKeyword(String keyword) {
        buyer.searches_for_items_containing(keyword);
    }

    @Then("I should only see items related to '(.*)'")
    public void resultsForACategoryAndKeywordInARegion(String keyword) {
        buyer.should_see_items_related_to(keyword);
    }
    
    
    @Given("^I want to update Payment File$")
    public void i_want_to_update_Payment_File()  {
      	 buyer.update_payment_file();
    }

    @Given("^I want to inject updated file in channel$")
    public void i_want_to_inject_updated_file_in_channel()  {
    	 buyer.update_payment_file();

    }

    @When("^I search for Payment in MassPAY database$")
    public void i_search_for_Payment_in_MassPAY_database()  {
    	 buyer.search_payment_file();

    }

    @Then("^I should see related database entry$")
    public void i_should_see_related_database_entry()  {
    	buyer.search_payment_file();

    }

    @Given("^xyz file is available in MassPAY database$")
    public void xyz_file_is_available_in_MassPAY_database()  {
    	buyer.search_payment_file();

    }

    @When("^I perform deep validation for containg payments$")
    public void i_perform_deep_validation_for_containg_payments()  {
        
    	buyer.payment_validation();
    }

    @Then("^I should see valid database entry for respective payments$")
    public void i_should_see_valid_database_entry_for_respective_payments()  {
    	buyer.transaction_validation();

    }
    
    @Given("^\"([^\"]*)\" file is available in MassPAY database$")
    public void file_is_available_in_MassPAY_database(String arg1)  {
    	  buyer.searches_for_items_containing(arg1);
    }
}