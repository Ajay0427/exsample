package managers;

import org.junit.Assert;




public class BuyerSteps {


                                                      
    public void opens_etsy_home_page() {
       System.out.println("BDD1");
    }

    
    public void searches_for_items_containing(String keywords) {
    	  System.out.println(keywords);
    	  Assert.assertEquals(keywords, "DDO");
    	//  Assert.assertEquals(keywords, "Wool");
    }

    
	
    public void should_see_items_related_to(String keywords) {
    	System.out.println(keywords);
    	Assert.assertEquals(keywords, "DDO");
    	//List<String> resultTitles = searchResultsPage.getResultTitles();
       /* resultTitles.stream().forEach(title -> assertThat(title.contains(keywords)));*/
    }

	/**
	 * 
	 */
	
	public void update_payment_file() {
		System.out.println("code reached here");
	}

	/**
	 * 
	 */
	
	public void search_payment_file() {
		// TODO Auto-generated method stub
		System.out.println("code reached here");
	}

	/**
	 * 
	 */
	
	public void payment_validation() {
		// TODO Auto-generated method stub
		System.out.println("code reached here");
	}

	/**
	 * 
	 */
	
	public void transaction_validation() {
		// TODO Auto-generated method stub
		System.out.println("code reached here");
	}
}