package com.test;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Sample {

	/**
	 * @param args
	 */

	@BeforeSuite
	public void BeforeSuite()
	{
		System.out.println("BeforeSuite");
	}
	@AfterSuite
	public void AfterSuite()
	{
		System.out.println("AfterSuite");
	}
	
	@BeforeTest
	public void BeforeTest()
	{
		System.out.println();
		System.out.println();
		System.out.println("BeforeTest");
	}
	
	@AfterTest
	public void AfterTest()
	{
		System.out.println("AfterTest");
	}
	
	@BeforeGroups
	public void BeforeGroups()
	{
		System.out.println("BeforeGroups");
	}
	
	@AfterGroups
	public void AfterGroups()
	{
		System.out.println("AfterGroups");
	}
	
	@BeforeClass
	public void BeforeClass()
	{
		System.out.println("BeforeClass");
	}
	
	@AfterClass
	public void AfterClass()
	{
		System.out.println("AfterClass");
	}
	
	@BeforeMethod
	public void BeforeMethod()
	{
		System.out.println("BeforeMethod");
	}
	
	@AfterMethod
	public void AfterMethod()
	{
		System.out.println("AfterMethod");
	}
	
	@Test	
	public void test3()
	{
		System.out.println("Test3");
	}
	
	@Test	
	public void test2()
	{
		System.out.println("Test2");
	}
public void test1()
{
	
	System.out.println("dsfds");
//System.setProperty("webdriver.gecko.driver","E:\\munna\\Driver\\geckodriver.exe");
System.setProperty("webdriver.gecko.driver" , "E:\\munna\\Driver\\geckodriver.exe");
WebDriver Driver = new FirefoxDriver();
Driver.get("https://github.com/cbeust/testng/");


try {
	Thread.sleep(10000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

 Set<String>  handeler = Driver.getWindowHandles();


for(String test :handeler)
{
	Driver.switchTo().window(test);
	System.out.println(Driver.getTitle());
	
	}

}
}