package com.test;

import org.testng.SkipException;
import org.testng.annotations.Test;

public class Application {

	/**
	 * @param argsssssqqqqqqqq
	 */
	@Test(priority =1)	
	public void launchBrowser()
	{
		System.out.println("Browser Launched");
		throw new SkipException(null);
	}
	
	
	@Test	(priority =2, dependsOnMethods = "launchBrowser")	
	public void logintoApplication()
	{
		System.out.println("Application Logged in");
	}
	
	@Test	(priority =3,groups = "reg")	 
	public void coverFlow()
	{
		System.out.println("verification covered");
	}
	
	@Test	(priority =4)	
	public void logout()
	{
		System.out.println("Application Logged out");
	}
	
	
	
}
