/**
 * 
 */
package com.test;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * @author ajay
 * created on Dec 17, 2017 6:53:13 PM
 */
public class dataProvidertest {

	/**
	 * @author ajay
	 * Created on  Dec 17, 2017 6:53:13 PM
	 */

	@Test (dataProvider = "getData")
	public void doLogin(String Uname, String Pword,String result, String Browser)
	{
  		System.out.println(Uname +"----"+Pword+"----"+result+"---"+Browser);
	}
	
	@DataProvider
	public Object[][] getData()
	{
		
		Object[][] Data = new Object[3][4];
		
				Data[0][0]= "u1";
				Data[0][1]= "p1";
				Data[0][2]= "Pass";
				Data[0][3]= "FF";
				

				Data[1][0]= "u2";
				Data[1][1]= "p2";
				Data[1][2]= "Pass";
				Data[1][3]= "Chrome";
				

				Data[2][0]= "u2";
				Data[2][1]= "p2";
				Data[2][2]= "Pass";
				Data[2][3]= "Ie";
		return Data;
	}
	 
}
