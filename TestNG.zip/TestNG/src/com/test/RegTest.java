/**
 * 
 */
package com.test;

import org.junit.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

/**
 * @author ajay
 * created on Dec 17, 2017 8:49:40 PM
 */
public class RegTest {

	/**
	 * @author ajay
	 * Created on  Dec 17, 2017 8:49:40 PM
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Test
	public void RegTesting()
	{
		
		String expectedTitle = "Commercial Banking ";
		//Something comming from webDriver  
		String ActualTitle = "Cards";
		// Critical Stop/Failure -Assert 
/*		System.out.println("before assertion");
		Assert.assertEquals(expectedTitle, ActualTitle);
		//Assert.assertTrue(false);
		System.out.println("After assertion");
		
		*/
		
	//Not Critical - continue execution 	
		SoftAssert as = new SoftAssert();
		
		
		as.assertTrue(2>11);
		as.assertAll();
		System.out.println("Asserttion Executed ");
		
		
	}
}
