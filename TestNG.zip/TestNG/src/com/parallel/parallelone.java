/**
 * 
 */
package com.parallel;

import org.testng.annotations.Test;

/**
 * @author ajay
 * created on Dec 17, 2017 11:27:23 PM
 */
public class parallelone {

	@Test
	public void testone() throws InterruptedException
	{
		System.out.println("test one start");
		Thread.sleep(2000);
		System.out.println("test one ends");
		
	}


}
