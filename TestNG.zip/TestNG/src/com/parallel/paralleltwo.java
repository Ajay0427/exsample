/**
 * 
 */
package com.parallel;

import org.testng.annotations.Test;

/**
 * @author ajay
 * created on Dec 17, 2017 11:30:42 PM
 */
public class paralleltwo {
	/**
	 * @author ajay
	 * Created on  Dec 17, 2017 11:30:42 PM
	 */
	@Test
	public void testtwo() throws InterruptedException
	{
		System.out.println("test two start");
		Thread.sleep(2000);
		System.out.println("test two ends");
		
	}
}

