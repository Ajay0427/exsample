package managers;
import net.thucydides.core.annotations.Step;



public class BuyerSteps {

    HomePage homePage;                                          
    SearchResultsPage searchResultsPage;

    @Step                                                       
    public void opens_etsy_home_page() {
       System.out.println("BDD1");
    }

    @Step
    public void searches_for_items_containing(String keywords) {
    	  System.out.println(keywords);
    	//  Assert.assertEquals(keywords, "Wool");
    }

    
	@Step
    public void should_see_items_related_to(String keywords) {
    	System.out.println(keywords);
    	// Assert.assertEquals(keywords, "Wool");
    	//List<String> resultTitles = searchResultsPage.getResultTitles();
       /* resultTitles.stream().forEach(title -> assertThat(title.contains(keywords)));*/
    }

	/**
	 * 
	 */
	@Step
	public void update_payment_file() {
		System.out.println("code reached here");
	}

	/**
	 * 
	 */
	@Step
	public void search_payment_file() {
		// TODO Auto-generated method stub
		System.out.println("code reached here");
	}

	/**
	 * 
	 */
	@Step
	public void payment_validation() {
		// TODO Auto-generated method stub
		System.out.println("code reached here");
	}

	/**
	 * 
	 */
	@Step
	public void transaction_validation() {
		// TODO Auto-generated method stub
		System.out.println("code reached here");
	}
}