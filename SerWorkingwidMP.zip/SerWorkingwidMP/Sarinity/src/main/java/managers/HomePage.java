package managers;

//@DefaultUrl("http://www.etsy.com")                      
//public class HomePage extends PageObject {              
public class HomePage {


    public void searchFor(String keywords) {
       // $("#search-query").sendKeys(keywords);          
       // searchButton.click();      
    	System.out.println(keywords);
    }

	/**
	 * @param keywords
	 */
	public void validateDB(String keywords) {
		// TODO Auto-generated method stub
		System.out.println(keywords + "DB ");
	}

	/**
	 * @param keywords
	 */
	public void DBcreation(String keywords) {
		System.out.println(keywords);
		
	}
}